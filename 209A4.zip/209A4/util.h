extern int match_arg(char *buf, char *command, int *arg);
extern int isalldigits(char *s);
extern char *memnewline(char *p, int size);  /* finds \r _or_ \n */
